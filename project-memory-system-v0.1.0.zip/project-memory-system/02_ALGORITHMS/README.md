# Алгоритмы
Идентификаторы ALG-0001 и далее; версии SemVer. Статусы: draft, tested, approved, deprecated. Approved только после явного подтверждения.
